<?php 
	$Server   = "localhost"; 
	$UserName =  "test";
	$Password =  "test";
	$DBname   =  "Realstate"; 
	
	
	
	 
             
      
             
             /// Border class 
     
             
             
	?>
	
	