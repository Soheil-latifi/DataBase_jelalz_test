<?php 
	$Server   = "localhost"; 
	$UserName =  "test";
	$Password =  "test";
	$DBname   =  "FinalState"; 
	
	
	
	 
             
      
             
             /// Border class 
     
             
             
	?>
	
	