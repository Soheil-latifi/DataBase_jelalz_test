<?php 
 include_once "PropertyClass.php";
 include_once "RentProperty.php";
 include_once "SaleProperty.php"; 
?>