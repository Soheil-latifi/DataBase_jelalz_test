

<?php
   class RentProperty extends Property{
	   
	   
      /* Member variables */
      
       private  $Mortage;
       private  $Rent;  
       private  $FamilyNum;  
       private  $Marriagestate;  
      /* Member functions */
  


	  function __construct()
	   {
      }
	  
	  
      function __destruct() {  
           
      }
  
  
      /* get,set functions */

	  
      public function setMortage($Mortage_){
         $this->Mortage = $Mortage_;
      } 
      public function getMortage(){
         return $this->Mortage ;
      }
	  
      public function setRent($Rent_){
         $this->Rent = $Rent_;
      } 
      public function getRent(){
         return $this->Rent ;
      }    
	  
      public function setFamilyNum($FamilyNum_){
         $this->FamilyNum = $FamilyNum_;
      } 
      public function getFamilyNum(){
         return $this->FamilyNum ;
      }
	  
      public function setMarriagestate($Marriagestate_){
         $this->Marriagestate = $Marriagestate_;
      } 
      public function getMarriagestate(){
         return $this->Marriagestate ;
      }
	

       /* Member functions */

	   /* Add RentProperty function */
      public function Add_RentProperty($par1,$par2,$par3,$par4)
	   {
			$this->Mortage= $par1;
			$this->Rent= $par2;
			$this->FamilyNum = $par3;
			$this->Marriagestate = $par4;
			$this->Postalcode = $par5;
      }
	  
	  
	  	 /* Show RentProperty function */
	  public function Show_RentProperty(){
      
	  
      }
	  
	  	  /* Edit RentProperty function */
	  public function Edit_RentProperty($OldPostalcode_,$Mortage_,$Rent_,$FamilyNum_,$Marriagestate_){
      
	  
      }
	  
	  	   /* Search RentProperty function */
	  public function Search_RentProperty($OldPostalcode_){
      
	  
      }

	  
	      /* Delete RentProperty function */
	  public function Delete_RentProperty($OldPostalcode_){
      

      }
	  

}
?>